#include <stdint.h>
#include <tm4c123gh6pm.h>
#include <stdlib.h>
#include <stdio.h>
uint8_t UART1_Receiver(void){
	  uint8_t data;
	  while((UART1_FR_R & (1<<4)) != 0){} //wait until Rx buffer is not full
    data = UART1_DR_R ;  	// before giving it another byte
   	return (unsigned char) data; 
}

void UART1_Transmitter(unsigned char data){
    while((UART1_FR_R & (1<<5)) != 0){} // wait until Tx buffer not full
    UART1_DR_R = data;                  // before giving it another byte
}
uint8_t UART2_Receiver(void){
	  uint8_t data;
 	  while((UART2_FR_R & (1<<4)) != 0){} //wait until Rx buffer is not full
    data = UART2_DR_R ;  	// before giving it another byte
   	return (unsigned char) data; 
}

void UART2_Transmitter(unsigned char data){
    while((UART2_FR_R & (1<<5)) != 0) // wait until Tx buffer not full
    UART2_DR_R = data;                  // before giving it another byte
}
void Delay(unsigned long counter){ 
		unsigned long i = 0;
		for(i=0; i< counter; i++);
}
void LCD_COMMAND(char COM){
	GPIO_PORTF_DATA_R &= 0x1E ; //LCD ENABLE = 0	
	GPIO_PORTB_DATA_R &= 0xF3; //RS,RW = 0
	COM = (GPIO_PORTD_DATA_R | (GPIO_PORTB_DATA_R & 0xF0)); //COM = 0,1,2,3,4,5,6,7 PINS
	GPIO_PORTF_DATA_R |= 0x01 ;	//LCD ENABLE = 1
	Delay(1000);
	GPIO_PORTF_DATA_R &= 0x1E ; //LCD ENABLE = 0
}	
void LCD_DATA(char DATA){
	GPIO_PORTF_DATA_R &= 0x1E ; //LCD ENABLE = 0	
	GPIO_PORTB_DATA_R |= 0x04; //RS = 1
	GPIO_PORTB_DATA_R &= 0xF7; //RW = 0	
	DATA = (GPIO_PORTD_DATA_R | (GPIO_PORTB_DATA_R & 0xF0)); //DATA = 0,1,2,3,4,5,6,7 PINS
	GPIO_PORTF_DATA_R |= 0x01 ;	//LCD ENABLE = 1
	Delay(1000);
	GPIO_PORTF_DATA_R &= 0x1E ; //LCD ENABLE = 0
}	
Double distance (double x1 , double y1, double x2 , double y2){
	int dis =( (x1-x2)^2 + (y1-y2)^2 )^0.5 ;
	int Final postionx = 6788,
	int Final position y= 6789;
	int Initial positionx= 134;
	int Initial positiony= 165;
	/*examples to get from gps*/

	int x1 = initial position x;
	int y1 = initial position y;

	int x2 = //current x coordinate read by the gps
	int y2 = //current y coordinate read by the gps

	while (x != final_positionx �� y != final postion y )
{
	int total += total ;
	Total += distance (x1,y1 ,x2,y2);
	x1= x2;
	Y1 =y2;
	X2= 6788; //current x coordinate read by the gps 6788 for example
	Y2= 6789; //current y coordinate read by the gps 6789 for example

	If (distance >= 100)
	Break;
}
void led_indicate_distance(){
if (distance >= 100;)
{
GPIO_PORTF_DATA_R |= 0X02;
}	
}
}
void initial(){	
	SYSCTL_RCGCGPIO_R |= 0x2A;
	SYSCTL_RCGCUART_R = SYSCTL_RCGCUART_R1 ;// UART1 CLK ENABLED
	UART1_CTL_R &= ~ UART_CTL_UARTEN; //UART1 DISABLED
	UART1_IBRD_R = 104; //(16MHz/(16*9600)) INTEGER VALUE
	UART1_FBRD_R = 11; // ((FRACTION OF IBRD *64) +0.5)	INTEGER VALUE
	UART1_LCRH_R |= 0x70;	// FIFO ENABLED, WORD LENGTH = 8bit
	UART1_CTL_R |= 0x301; // TX,RX, UARTEN ENABLED
	SYSCTL_RCGCUART_R = SYSCTL_RCGCUART_R2 ; //UART2 CLK ENABLED
	UART2_CTL_R &= ~ UART_CTL_UARTEN; //UART2 DISABLED
	UART2_IBRD_R = 104; //(16MHz/(16*9600)) INTEGER VALUE
	UART2_FBRD_R = 11; // ((FRACTION OF IBRD *64) +0.5)	INTEGER VALUE
	UART2_LCRH_R |= 0x70;	// FIFO ENABLED, WORD LENGTH = 8bit
	UART2_CTL_R |= 0x301; // TX,RX, UARTEN ENABLED		
	while(!(SYSCTL_PRGPIO_R &0x2A));	
//PORT F  (FOR LEDS & SWITCH1 & LCD ENABLE ,PF0 )
	GPIO_PORTF_LOCK_R = 0x4C4F434B;
	GPIO_PORTF_CR_R |= 0x1F;
	GPIO_PORTF_DIR_R |= 0x0E;	
	GPIO_PORTF_DEN_R |= 0x1F;
	GPIO_PORTF_AMSEL_R = 0;
	GPIO_PORTF_AFSEL_R = 0;
	GPIO_PORTF_PCTL_R = 0;
	GPIO_PORTF_PUR_R = 0x11;
//PORT B	(LCD 4,5,6,7 PINS & GPS B0,B1 & (RS,RW) B2,B3)	
	GPIO_PORTB_CR_R = 0xFF;
	GPIO_PORTB_DIR_R |= 0xFE;	
	GPIO_PORTB_DEN_R |= 0xFF;
	GPIO_PORTB_AMSEL_R = 0;
	GPIO_PORTB_AFSEL_R = 0x03;
	GPIO_PORTB_PCTL_R = 0x11;
	GPIO_PORTB_PUR_R = 0x00;
//PORT D  (LCD 0,1,2,3 PINS & BLUETOOTH D6,D7)
	GPIO_PORTD_LOCK_R = 0x4C4F434B;
	GPIO_PORTD_CR_R = 0xCF;
	GPIO_PORTD_DIR_R |= 0x8F;	
	GPIO_PORTD_DEN_R |= 0xCF;
	GPIO_PORTD_AMSEL_R = 0;
	GPIO_PORTD_AFSEL_R = 0xC0;
	GPIO_PORTD_PCTL_R = 0x11000000;
	GPIO_PORTD_PUR_R = 0x00;		
	LCD_COMMAND(0x01); //CLEAR
	LCD_COMMAND(0x06); //SET DIRECTION OF CURSOR SHIFT TO RIGHT 	
}
int main(){
	initial();
	LCD_DATA('A');
	LCD_COMMAND(0x06);
	LCD_DATA('B');
		}

		
